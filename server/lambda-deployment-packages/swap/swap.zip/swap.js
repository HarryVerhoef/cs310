"use static";
const queryString = require("querystring");
const axios = require("axios");

const client_id = "ff19e2ea3546447e916e43dcda51a298";
const client_secret = process.env.CLIENT_SECRET;


exports.handler = async (event, context, callback) => {
    console.log("POST /swap");

    const url = "https://accounts.spotify.com/api/token";
    const body = {
        grant_type: "authorization_code",
        code: event.code,
        redirect_uri: "juke://spotify-login-callback"
    }
    const config = {
        headers: {
            "Authorization": "Basic " + Buffer.from(client_id + ":" + client_secret).toString("base64"),
        }
    }

    try {
        let response = await axios({
           method: "POST",
           url: url,
           data: queryString.stringify(body),
           config: config
        });
        return response.body;
    } catch (error) {
        console.log(error);
        const response = {
            statusCode: 500,
            body: JSON.stringify(error)
        }
    }
};
